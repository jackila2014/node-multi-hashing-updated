#pragma once

#include <stdint.h>

void x13_hash(const char* input, char* output, uint32_t len);
