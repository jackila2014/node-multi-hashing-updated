#include "groestl.h"
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>

#include "sha3/sph_groestl.h"
#include "sha256.h"

void groestl_hash(const char* input, char* output, uint32_t len)
{
    char hash1[64];
    char hash2[64];
    
    sph_groestl512_context ctx_groestl;
    sph_groestl512_init(&ctx_groestl);
    sph_groestl512(&ctx_groestl, input, len);
    sph_groestl512_close(&ctx_groestl, &hash1);
    
    sph_groestl512(&ctx_groestl, hash1, 64);
    sph_groestl512_close(&ctx_groestl, &hash2);
    
    memcpy(output, &hash2, 32);
}

void groestlmyriad_hash(const char* input, char* output, uint32_t len)
{
    char temp[64];
    
    sph_groestl512_context ctx_groestl;
    sph_groestl512_init(&ctx_groestl);
    sph_groestl512(&ctx_groestl, input, len);
    sph_groestl512_close(&ctx_groestl, &temp);
    
    sha256_ctx ctx_sha256;
    sha256_init(&ctx_sha256);
    sha256_update(&ctx_sha256, &temp, 64);
    sha256_final((unsigned char*) output, &ctx_sha256);
}

