# 1.0.0 (2020-08-26)


### Bug Fixes

* building on macos ([951ba10](https://github.com/zone117x/node-multi-hashing/commit/951ba106e234ca99d2b78a0f9b2881fb3f90c81c))
* bump test timeout ([9dc7dab](https://github.com/zone117x/node-multi-hashing/commit/9dc7dab38186c35723e57d3625ccdef1a13daea6))
* run gh actions on all branches ([1aa6f9e](https://github.com/zone117x/node-multi-hashing/commit/1aa6f9e8f938cba71ee82722abe593d799b15be8))
